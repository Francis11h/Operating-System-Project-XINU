abs(int arg)
{

	if(arg < 0)
		arg = -arg;
	return(arg);
}
